This is a library for our Optical Fingerprint sensor

  Pick one up today in the adafruit shop!
  ------> http://www.adafruit.com/products/751

These displays use TTL Serial to communicate, 2 pins are required to  
interface

Adafruit invests time and resources providing this open source code, 
please support Adafruit and open-source hardware by purchasing 
products from Adafruit!

Written by Limor Fried/Ladyada  for Adafruit Industries.  
BSD license, check license.txt for more information
All text above must be included in any redistribution

To download. click the DOWNLOADS button in the top right corner, rename the uncompressed folder Adafruit_Fingerprint. Check that the Adafruit_Fingerprint folder contains Adafruit_Fingerprint.cpp and Adafruit_Fingerprint.h

Place the Adafruit_Fingerprint library folder your <arduinosketchfolder>/libraries/ folder. You may need to create the libraries subfolder if its your first library. Restart the IDE.
